package edu.ksu.canvas.constants;

public class CanvasConstants {

    public static final String ACCOUNT_ID="1";
    public static final String MASQUERADE_SIS_USER="sis_user_id";
    public static final String MASQUERADE_CANVAS_USER="canvas_user_id";

    public static final String URLENCODING_TYPE = "UTF-8";
}
