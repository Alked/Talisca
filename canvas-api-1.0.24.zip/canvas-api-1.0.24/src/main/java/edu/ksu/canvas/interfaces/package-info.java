/**
 * Interfaces defining Canvas API functionality
 */
package edu.ksu.canvas.interfaces;
