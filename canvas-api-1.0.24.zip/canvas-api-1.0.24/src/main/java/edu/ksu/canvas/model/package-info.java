/**
 * POJOs to parse Canvas API data into
 */
package edu.ksu.canvas.model;
