package edu.ksu.canvas.interfaces;

import edu.ksu.canvas.model.GradingStandard;

public interface GradingStandardWriter extends CanvasWriter<GradingStandard, GradingStandardWriter> {
}
