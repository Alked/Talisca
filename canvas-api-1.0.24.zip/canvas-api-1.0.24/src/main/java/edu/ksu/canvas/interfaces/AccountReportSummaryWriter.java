package edu.ksu.canvas.interfaces;

import edu.ksu.canvas.model.report.AccountReportSummary;

public interface AccountReportSummaryWriter extends CanvasWriter<AccountReportSummary, AccountReportSummaryWriter>  {
}
