/**
 * This package provides common utility functions to reduce code duplication
 * for things like building API URLs.
 */
package edu.ksu.canvas.util;
