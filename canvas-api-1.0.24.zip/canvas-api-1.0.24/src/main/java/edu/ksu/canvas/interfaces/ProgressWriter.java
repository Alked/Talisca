package edu.ksu.canvas.interfaces;

import edu.ksu.canvas.model.Progress;

public interface ProgressWriter extends CanvasWriter<Progress, ProgressWriter> {

}
