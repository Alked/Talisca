package edu.ksu.canvas.interfaces;

import edu.ksu.canvas.model.AccountAdmin;

public interface AdminWriter extends CanvasWriter<AccountAdmin, AdminWriter> {

}
