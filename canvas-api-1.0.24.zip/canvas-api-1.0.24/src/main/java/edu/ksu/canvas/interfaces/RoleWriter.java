package edu.ksu.canvas.interfaces;

import edu.ksu.canvas.model.Role;

public interface RoleWriter extends CanvasWriter<Role, RoleWriter> {

}
