package edu.ksu.canvas.interfaces;


import edu.ksu.canvas.model.EnrollmentTerm;

public interface EnrollmentTermWriter extends CanvasWriter<EnrollmentTerm, EnrollmentTermWriter> {

}
