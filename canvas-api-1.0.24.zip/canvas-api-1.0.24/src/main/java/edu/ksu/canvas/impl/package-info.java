/**
 * Default implementations for Canvas API calls.
 */
package edu.ksu.canvas.impl;
