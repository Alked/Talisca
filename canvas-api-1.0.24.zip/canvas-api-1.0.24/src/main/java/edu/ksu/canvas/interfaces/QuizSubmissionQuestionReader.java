package edu.ksu.canvas.interfaces;

import edu.ksu.canvas.model.assignment.QuizSubmissionQuestion;

public interface QuizSubmissionQuestionReader extends CanvasReader<QuizSubmissionQuestion, QuizSubmissionQuestionReader> {
}
