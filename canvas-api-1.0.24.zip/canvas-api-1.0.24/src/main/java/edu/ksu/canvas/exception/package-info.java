/**
 * Exceptions thrown when canvas returns errors.
 */
package edu.ksu.canvas.exception;