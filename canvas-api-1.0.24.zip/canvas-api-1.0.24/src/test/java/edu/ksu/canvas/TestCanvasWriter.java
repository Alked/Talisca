package edu.ksu.canvas;

import edu.ksu.canvas.interfaces.CanvasWriter;
import edu.ksu.canvas.model.TestCanvasModel;

public interface TestCanvasWriter extends CanvasWriter<TestCanvasModel, TestCanvasWriter> {
}
